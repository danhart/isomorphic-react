'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = {
  development: {
    loggerMode: 'dev'
  },
  production: {
    loggerMode: 'combined'
  }
};